package interceptor;

import com.jfinal.aop.Before;

public class testInterceptorService {

    @Before(DemoInterceptor.class)
    public String test(String name) {
        System.out.println(name);
        return "test方法返回";
    }
}
