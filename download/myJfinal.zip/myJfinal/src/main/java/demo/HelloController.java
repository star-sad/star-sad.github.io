package demo;

import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.upload.UploadFile;
import interceptor.testInterceptorService;

public class HelloController extends Controller {
    @Inject
    private testInterceptorService srv;

    public void index(){
        renderText("Hello World!!!!");
        //System.out.println(get(0));
        //System.out.println(get(1));
    }

    //@Before(DemoInterceptor.class)
    public void test(){
        System.out.println("---------test");
        srv.test("张三");
        //(new testInterceptorService()).test("张三");
        renderText("it is a test!");
    }

    public void saveUser() {
        User user = getBean(User.class);
        System.out.println(user.getName());
        System.out.println(user.getAge());
        renderText("提交成功");
    }

    @ActionKey("/testView")
    public void testView() {
        render("testView.html");
    }

    public void testUpload() {
        render("testUpload.html");
    }

    public void uploadFile() {
        UploadFile uploadFile = getFile("file");
        System.out.println(uploadFile.getContentType());
        System.out.println(uploadFile.getFileName());
        System.out.println(uploadFile.getOriginalFileName());
        System.out.println(uploadFile.getUploadPath());

        System.out.println(get("name"));
        System.out.println(get("age"));
        set("msg", "上传成功！");
        render("testUpload.html");
    }

    public void downloadFile() {
        renderFile("定期删除的.txt");
        //renderText("sdsds");
    }
}
