package demo;

import com.jfinal.server.undertow.UndertowServer;

public class StartMain {
    public static void main(String[] args){
        UndertowServer.start(DemoConfig.class,8080,true);
    }
}
