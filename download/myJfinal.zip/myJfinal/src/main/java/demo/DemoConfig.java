package demo;


import com.jfinal.config.*;
import com.jfinal.ext.proxy.CglibProxyFactory;
import com.jfinal.render.ErrorRender;
import com.jfinal.render.ViewType;
import com.jfinal.template.Engine;
import interceptor.DemoInterceptor;


public class DemoConfig extends JFinalConfig {
    @Override
    public void configConstant(Constants me) {
        me.setDevMode(true);
        me.setError404View("/err/My404.html");
        //配置urlPara参数分隔字符，默认为“-”
        me.setUrlParaSeparator("~");
        me.setBaseUploadPath("upload/test");
        me.setBaseDownloadPath("download");
        me.setInjectDependency(true);
        //me.setInjectSuperClass(true);
        //me.setProxyFactory(new CglibProxyFactory());
        me.setProxyFactory(new CglibProxyFactory());
    }

    @Override
    public void configRoute(Routes routes) {
        //routes.setBaseViewPath("/view");
        //routes.add("/hello",HelloController.class,"/hello2");
    	routes.add("/hello",HelloController.class);
    }

    @Override
    public void configEngine(Engine engine) {

    }

    @Override
    public void configPlugin(Plugins plugins) {

    }

    @Override
    public void configInterceptor(Interceptors interceptors) {
        //interceptors.add(new DemoInterceptor());
        //interceptors.addGlobalServiceInterceptor(new BbbInterceptor());
    }

    @Override
    public void configHandler(Handlers handlers) {

    }
}
